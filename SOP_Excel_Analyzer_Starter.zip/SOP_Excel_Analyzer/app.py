"""Guided depreciation preflight and a separate generic example report."""

import os
import queue
import sys
import threading
import tkinter as tk
import traceback
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from analysis import load_rules

ROOT = Path(sys.executable if getattr(sys, "frozen", False) else __file__).resolve().parent


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CAPEX Depreciation Analyzer")
        self.geometry("720x650")
        self.resizable(False, False)
        self.events = queue.Queue()
        self.last_report = None
        self.last_review = None
        self.busy = False
        self.rules = None
        frame = ttk.Frame(self, padding=24)
        frame.pack(fill="both", expand=True)
        ttk.Label(frame, text="CAPEX Depreciation Analyzer", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(frame, text="Step 1: inspect the existing model and the accounting GRP export. This review will not change either file.", wraplength=630).pack(anchor="w", pady=(9, 14))
        self.model = tk.StringVar()
        self.grp = tk.StringVar()
        self._file_row(frame, "Existing CAPEX model workbook", self.model)
        self._file_row(frame, "GRP-FACIP+A_D accounting export", self.grp)
        review_actions = ttk.Frame(frame)
        review_actions.pack(anchor="w", pady=(5, 12))
        self.review_button = ttk.Button(review_actions, text="Review SOP Inputs", command=self.review)
        self.review_button.pack(side="left")
        self.open_review_button = ttk.Button(review_actions, text="Open Review", state="disabled", command=self.open_review)
        self.open_review_button.pack(side="left", padx=8)
        ttk.Label(frame, text="The full depreciation model update needs the actual model and source reports so its row boundaries, formulas and ties can be verified.", wraplength=630).pack(anchor="w", pady=(0, 12))
        ttk.Separator(frame).pack(fill="x", pady=5)
        ttk.Label(frame, text="Generic PivotTable example (unrelated to the depreciation SOP)", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(8, 0))
        self.rule_label = ttk.Label(frame, text="Loading rules…", wraplength=540)
        self.rule_label.pack(anchor="w", pady=(5, 10))
        ttk.Label(frame, text="Input Excel or CSV file").pack(anchor="w")
        row = ttk.Frame(frame)
        row.pack(fill="x", pady=(4, 16))
        self.selected = tk.StringVar()
        ttk.Entry(row, textvariable=self.selected, state="readonly", width=65).pack(side="left")
        self.browse_button = ttk.Button(row, text="Browse…", command=self.browse)
        self.browse_button.pack(side="left", padx=8)
        actions = ttk.Frame(frame)
        actions.pack(anchor="w")
        self.run_button = ttk.Button(actions, text="Analyze Data", command=self.analyze)
        self.run_button.pack(side="left")
        self.demo_button = ttk.Button(actions, text="Try Example", command=self.example)
        self.demo_button.pack(side="left", padx=8)
        self.open_button = ttk.Button(actions, text="Open Report", state="disabled", command=self.open_report)
        self.open_button.pack(side="left")
        self.status = tk.StringVar(value="Choose the two workbooks above to inspect the SOP inputs.")
        ttk.Label(frame, textvariable=self.status, wraplength=540).pack(anchor="w", pady=(25, 0))
        ttk.Separator(frame).pack(fill="x", pady=18)
        ttk.Label(frame, text="The source files are never changed. Reviews and example reports are saved in the Reports folder.", wraplength=630).pack(anchor="w")
        self.after(100, self.poll)
        try:
            self.rules = load_rules(ROOT / "rules.json")
            self.rule_label.configure(text=f"Rules: {self.rules['name']} · version {self.rules['version']} · status {self.rules['status']}")
        except Exception as error:
            self.rule_label.configure(text=f"Rules error: {error}")
        self.run_button.configure(state="normal" if self.rules and self.rules["status"] == "approved" else "disabled")

    def _file_row(self, parent, label, variable):
        ttk.Label(parent, text=label).pack(anchor="w")
        row = ttk.Frame(parent)
        row.pack(fill="x", pady=(3, 8))
        ttk.Entry(row, textvariable=variable, state="readonly", width=75).pack(side="left")
        ttk.Button(row, text="Browse…", command=lambda: self.browse_into(variable)).pack(side="left", padx=8)

    def browse_into(self, variable):
        value = filedialog.askopenfilename(title="Select Excel workbook", filetypes=[("Excel workbooks", "*.xlsx *.xlsm *.xls *.xlsb")])
        if value:
            variable.set(value)

    def review(self):
        if not self.model.get() or not self.grp.get():
            messagebox.showinfo("Select two workbooks", "Select the existing CAPEX model and the GRP accounting export.")
            return
        if self.busy:
            return
        self.busy = True
        self.review_button.configure(state="disabled")
        self.demo_button.configure(state="disabled")
        self.open_review_button.configure(state="disabled")
        self.status.set("Starting read-only inspection…")
        threading.Thread(target=self.review_worker, daemon=True).start()

    def review_worker(self):
        try:
            import pythoncom
            pythoncom.CoInitialize()
            try:
                from depreciation_preflight import run_preflight
                report = run_preflight(self.model.get(), self.grp.get(), ROOT / "Reports",
                                       notify=lambda text: self.events.put(("status", text)))
                self.events.put(("review_done", report))
            finally:
                pythoncom.CoUninitialize()
        except Exception as error:
            self.log_error(error)

    def open_review(self):
        if self.last_review and Path(self.last_review).is_file():
            os.startfile(self.last_review)

    def browse(self):
        value = filedialog.askopenfilename(title="Select raw data", filetypes=[("Excel and CSV", "*.xlsx *.xlsm *.xls *.csv")])
        if value:
            self.selected.set(value)

    def analyze(self):
        if not self.selected.get():
            messagebox.showinfo("Choose data", "Select a raw data file first.")
            return
        self.start(Path(self.selected.get()), False)

    def example(self):
        if not self.rules or self.rules["status"] != "example":
            messagebox.showinfo("Example unavailable", "Example mode is available only with example rules.")
            return
        self.start(ROOT / "examples" / "example_data.csv", True)

    def start(self, path, example):
        if self.busy:
            return
        self.busy = True
        self.run_button.configure(state="disabled")
        self.demo_button.configure(state="disabled")
        self.open_button.configure(state="disabled")
        self.status.set("Starting Excel…")
        threading.Thread(target=self.worker, args=(path, example), daemon=True).start()

    def worker(self, path, example):
        try:
            import pythoncom
            pythoncom.CoInitialize()
            try:
                from excel_report import build_report
                output, result = build_report(path, ROOT / "Reports", self.rules,
                                              example=example, notify=lambda text: self.events.put(("status", text)))
                self.events.put(("done", output, result))
            finally:
                pythoncom.CoUninitialize()
        except Exception as error:
            self.log_error(error)

    def log_error(self, error):
        log_path = ROOT / "analyzer_error.log"
        try:
            log_path.write_text(traceback.format_exc(), encoding="utf-8")
            detail = f"{error}\n\nIf this happens again, send analyzer_error.log from the app folder."
        except OSError:
            detail = str(error)
        self.events.put(("error", detail))

    def poll(self):
        try:
            while True:
                event = self.events.get_nowait()
                if event[0] == "status":
                    self.status.set(event[1])
                elif event[0] == "review_done":
                    self.busy = False
                    self.last_review = event[1]
                    self.status.set("Read-only review complete. Open Review to see what the SOP update still needs.")
                    self.open_review_button.configure(state="normal")
                    self.review_button.configure(state="normal")
                    self.demo_button.configure(state="normal" if self.rules and self.rules["status"] == "example" else "disabled")
                elif event[0] == "done":
                    self.busy = False
                    self.last_report = event[1]
                    issues = event[2]["issues"]
                    self.status.set(f"Report ready. {len(event[2]['clean']):,} rows retained; {len(issues):,} rows flagged or excluded. Open the QC sheet for details.")
                    self.open_button.configure(state="normal")
                    self.run_button.configure(state="normal" if self.rules["status"] == "approved" else "disabled")
                    self.demo_button.configure(state="normal" if self.rules["status"] == "example" else "disabled")
                    self.review_button.configure(state="normal")
                elif event[0] == "error":
                    self.busy = False
                    self.status.set("Review stopped. No new report was saved.")
                    self.review_button.configure(state="normal")
                    self.run_button.configure(state="normal" if self.rules and self.rules["status"] == "approved" else "disabled")
                    self.demo_button.configure(state="normal" if self.rules and self.rules["status"] == "example" else "disabled")
                    messagebox.showerror("Unable to analyze", event[1])
        except queue.Empty:
            pass
        self.after(100, self.poll)

    def open_report(self):
        if self.last_report and Path(self.last_report).is_file():
            os.startfile(self.last_report)


if __name__ == "__main__":
    App().mainloop()
