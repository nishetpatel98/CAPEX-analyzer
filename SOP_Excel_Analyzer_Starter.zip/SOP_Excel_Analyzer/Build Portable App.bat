@echo off
setlocal
cd /d "%~dp0"
set "BUILD_LOG=%~dp0portable_build.log"
set "OUT_DIR=%~dp0dist\CAPEX_Depreciation_Analyzer"
>"%BUILD_LOG%" echo CAPEX Depreciation Analyzer portable build

if not exist ".venv\Scripts\python.exe" (
  echo Run Setup.bat on THIS Windows computer first. Do not run setup on the destination computer.
  pause
  exit /b 1
)

echo Installing the Windows app builder locally...
".venv\Scripts\python.exe" -m pip install "pyinstaller>=6,<7" >>"%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed

echo Building portable app. This may take several minutes...
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --clean --onedir --windowed --name CAPEX_Depreciation_Analyzer --hidden-import=excel_report --hidden-import=depreciation_preflight --hidden-import=pythoncom --hidden-import=pywintypes --collect-submodules=win32com app.py >>"%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed

copy /Y "rules.json" "%OUT_DIR%\rules.json" >>"%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed
if not exist "%OUT_DIR%\examples" mkdir "%OUT_DIR%\examples"
copy /Y "examples\example_data.csv" "%OUT_DIR%\examples\example_data.csv" >>"%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed
copy /Y "README.md" "%OUT_DIR%\README.md" >>"%BUILD_LOG%" 2>&1
if errorlevel 1 goto failed

echo.
echo Portable app built in:
echo %OUT_DIR%
echo.
echo Test CAPEX_Depreciation_Analyzer.exe here first. Then copy the ENTIRE folder to the other Windows computer.
echo The destination needs desktop Excel but does not need Python or Setup.bat.
pause
exit /b 0

:failed
echo.
echo Portable build failed. Open portable_build.log in this folder for the error.
echo %BUILD_LOG%
echo.
pause
exit /b 1
