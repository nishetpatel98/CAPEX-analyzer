# CAPEX Depreciation Analyzer — guided starter

A Windows desktop tool for a nontechnical operator. Its **Review SOP Inputs** workflow accepts the existing CAPEX depreciation model and the accounting `GRP-FACIP+A_D` workbook, inspects both read-only, and opens a written review of what is present and what needs verification. It checks for the two asset listing tabs, required model sheets, candidate Projects labels, the current value of `Accounting FA Data!B1`, and external workbook links. It never changes the accounting files during this review.

The earlier **Try Example** remains available for a separate generic PivotTable demonstration. That example is not a depreciation report. Its rules stay blocked for live input.

## Before live use

**The SOP PDF does not contain the row addresses, formula definitions, source headers, linked workbook layout, or reconciliation cells needed to safely update the financial model.** Therefore Review SOP Inputs is read-only. The generic Analyze Data button remains disabled with its example rules. Those generic rules are not a substitute for implementing the depreciation model workflow. The operator does not edit rules or code.

To finish the model update, provide an accessible copy of the CAPEX model, a representative `GRP-FACIP+A_D` export, the CIP by Project/YTD CIP Cost and CIP Accrual Listing sources, the Variance File, and a manually verified prior-month result where available. These can be redacted if relationships, headers, formulas and sheet layouts remain intact. The SOP also calls for checking Mobility depreciation links and confirming project timing with managers. Those review decisions cannot be inferred from the PDF alone. Jev is not connected because the SOP does not define a bounded classification question for it.

## Windows setup, once

Requires Windows 10/11, desktop Microsoft Excel, Python 3.10+ and an internet connection to install `pywin32`. Unzip the project, double-click `Setup.bat`, and then double-click `Run Analyzer.bat`. After setup, operators use only `Run Analyzer.bat`. If your organization restricts installations, IT can install the dependency and provide a shortcut. Excel web alone is not sufficient.

### A second Windows computer without admin or Python

On the **first Windows computer**, run `Setup.bat`, then `Build Portable App.bat`. The build requires internet access and installs PyInstaller only into this project's `.venv`. Test the generated `dist\CAPEX_Depreciation_Analyzer\CAPEX_Depreciation_Analyzer.exe` on that computer. Copy **the entire** `dist\CAPEX_Depreciation_Analyzer` folder to a user-writable location such as Documents on the second computer, and open the `.exe` there. Do **not** run `Setup.bat` on the second computer. It does not need Python or administrator installation, but it must have desktop Microsoft Excel and be permitted by organizational application policy to run the executable. A Windows executable must be built on Windows; this project contains the builder, not a prebuilt `.exe`.

`Setup.bat` now prints the result before its Press any key prompt and writes `setup.log` next to the script. A closing window after pressing a key does not establish success: check for the words **Setup complete** or open the log. A portable build writes `portable_build.log` if it fails.

For the depreciation workflow, choose the existing model and GRP export, click **Review SOP Inputs**, then **Open Review**. This is a preparation step for configuring the monthly update safely.

The **Try Example** button creates a generic report from `examples/example_data.csv`. **Analyze Data** asks for an input file and will work only after its generic rules have been approved. Example charts are ordinary Excel charts driven by native PivotTable output; they are not standalone PivotCharts.

If a report fails, the app displays an error and writes `analyzer_error.log` next to the launcher. Share that log to diagnose the exact Excel step. To install an updated package, close the app, extract the ZIP over the old project folder, and run `Run Analyzer.bat` again. You do not need to rerun Setup unless the Python environment was removed.

## Report and checks

The depreciation review is a text file named `Depreciation_Preflight_...txt` containing structural checks and the monthly controls called for by the SOP. It makes no claims that CIP and FA actuals tie until the source files and reconciliation cells are supplied.

The generic example report contains:

- `Raw_Data`: a value copy of the input; the original file remains untouched.
- `Processed_Data`: rows retained under the configured rules and derived fields.
- One sheet per configured PivotTable and a `Charts` sheet.
- `QC`: source and retained row counts, exclusions, invalid records and rule version.

Input `.xlsx`, `.xlsm`, `.xls`, or `.csv` must have unique, nonblank headers in the first row. Excel files use the configured sheet or the first sheet. Each run creates a new timestamped report in `Reports`. If validation or report generation fails, no partial report is published.

## Generic example configuration (separate from depreciation)

`rules.json` supports a separate, simple flat-file PivotTable example. It is not capable of encoding this existing depreciation model's linked worksheets, row inserts, and reconciliations. Leave the example status unchanged for the CAPEX task.

Native PivotTables and chart behavior require a final run on a Windows computer with desktop Excel. The pure processing checks included in `tests` can run on any OS with `python -m unittest discover -s tests`.
