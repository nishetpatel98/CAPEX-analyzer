@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\pythonw.exe" (
  echo Run Setup.bat first.
  pause
  exit /b 1
)
start "SOP Excel Analyzer" ".venv\Scripts\pythonw.exe" "app.py"
