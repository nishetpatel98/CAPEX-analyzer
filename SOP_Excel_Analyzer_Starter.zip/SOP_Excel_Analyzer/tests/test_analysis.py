import datetime as dt
import unittest
from pathlib import Path

from analysis import AnalysisError, _date_month, load_rules, process, read_csv
from excel_report import _pivot_source_address
from depreciation_preflight import populated_rows, projects_candidates

BASE = Path(__file__).resolve().parents[1]


class AnalysisTests(unittest.TestCase):
    def setUp(self):
        self.rules = load_rules(BASE / "rules.json")

    def test_example_rows_and_counts(self):
        headers, rows = read_csv(BASE / "examples" / "example_data.csv")
        result = process(headers, rows, self.rules)
        self.assertEqual(result["source_count"], 7)
        self.assertEqual(len(result["clean"]), 6)
        self.assertEqual(result["issues"], [(7, "Filtered: Status", "excluded")])
        monthly = {(row[5], row[1]) for row in result["clean"]}
        self.assertEqual(monthly, {("2026-07", "A"), ("2026-07", "B"), ("2026-08", "A"), ("2026-08", "B")})
        self.assertEqual(sum(row[6] for row in result["clean"]), 2)

    def test_malformed_input_is_flagged(self):
        rows = [["not-a-date", "A", "Ada", "22", "Pass"],
                ["2026-07-01", "A", "Ada", "NaN", "Pass"],
                ["2026-07-02", "A", "Ada", "10", "Pass"]]
        result = process(["Date", "Product", "Operator", "Result", "Status"], rows, self.rules)
        self.assertEqual(len(result["clean"]), 1)
        self.assertEqual([i[0] for i in result["issues"]], [2, 3])

    def test_missing_column_stops(self):
        with self.assertRaisesRegex(AnalysisError, "Missing required columns: Status"):
            process(["Date", "Product", "Operator", "Result"], [["2026-07-01", "A", "Ada", "1"]], self.rules)

    def test_excel_serial_date(self):
        serial = (dt.datetime(2026, 9, 26) - dt.datetime(1899, 12, 30)).days
        self.assertEqual(_date_month(serial), "2026-09")

    def test_excel_address_property_is_not_called(self):
        class Range:
            Address = "$A$1:$G$8"
        self.assertEqual(_pivot_source_address(Range()), "'Processed_Data'!$A$1:$G$8")

    def test_preflight_reports_populated_rows_and_candidate_labels_without_guessing_boundary(self):
        rows = [["A1", None], ["", ""], [None, 19]]
        self.assertEqual(populated_rows(rows), 2)
        self.assertEqual(projects_candidates([["Intro", "Projects"], ["Project assets", None]], first_row=4), [(4, 2)])


if __name__ == "__main__":
    unittest.main()
