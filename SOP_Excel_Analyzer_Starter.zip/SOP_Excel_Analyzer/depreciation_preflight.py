"""Read-only inspection of the CAPEX model and accounting export.

The SOP provides workflow instructions, but does not specify enough workbook
addresses to safely edit a financial forecast without examining the template.
"""

import datetime as dt
from pathlib import Path

from analysis import AnalysisError

MODEL_SHEETS = (
    "Accounting FA Data", "Asset Level Summary", "Topsides",
    "26 Monthly Depreciation", "Depreciation Summary", "Project", "Asset Type",
)
GRP_SHEETS = ("2. Asset Listing", "2. Asset Listing v2")


def populated_rows(rows):
    """Count nonempty source rows from a matrix that excludes the first row."""
    return sum(any(value is not None and str(value).strip() for value in row) for row in rows)


def projects_candidates(rows, first_row=1):
    """Find labels that might identify the green Projects section; never edit by this guess."""
    return [(first_row + offset, column + 1) for offset, row in enumerate(rows)
            for column, value in enumerate(row)
            if isinstance(value, str) and value.strip().casefold() == "projects"]


def _matrix(value):
    if value is None:
        return []
    if not isinstance(value, tuple):
        return [[value]]
    if value and not isinstance(value[0], tuple):
        return [list(value)]
    return [list(row) for row in value]


def _sheet(workbook, name):
    matches = [workbook.Worksheets(i) for i in range(1, workbook.Worksheets.Count + 1)
               if workbook.Worksheets(i).Name.casefold() == name.casefold()]
    return matches[0] if len(matches) == 1 else None


def _source_count(sheet):
    last = sheet.UsedRange.Row + sheet.UsedRange.Rows.Count - 1
    if last > 200001:
        raise AnalysisError(f"{sheet.Name} exceeds the 200,000-row inspection limit.")
    if last < 2:
        return 0
    return populated_rows(_matrix(sheet.Range(sheet.Cells(2, 1), sheet.Cells(last, 37)).Value2))


def _open(excel, path):
    return excel.Workbooks.Open(str(path), UpdateLinks=0, ReadOnly=True, IgnoreReadOnlyRecommended=True)


def run_preflight(model_path, grp_path, report_dir, *, notify=lambda message: None):
    """Inspect two workbooks with Excel, save a text report, and change neither."""
    model_path, grp_path = Path(model_path).resolve(), Path(grp_path).resolve()
    for path in (model_path, grp_path):
        if not path.is_file() or path.suffix.lower() not in (".xlsx", ".xlsm", ".xls", ".xlsb"):
            raise AnalysisError("Select existing Excel workbooks for the model and GRP source.")
    if model_path == grp_path:
        raise AnalysisError("Choose two different files: the model and the accounting GRP export.")

    from win32com.client import DispatchEx
    excel = DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    opened = []
    try:
        try:
            excel.AutomationSecurity = 3
        except Exception as error:
            raise AnalysisError("Excel could not disable macros before reading the files.") from error
        notify("Reading the model and accounting export…")
        model = _open(excel, model_path)
        opened.append(model)
        grp = _open(excel, grp_path)
        opened.append(grp)
        lines = ["CAPEX DEPRECIATION SOP — READ-ONLY PREFLIGHT",
                 f"Generated: {dt.datetime.now():%Y-%m-%d %H:%M}",
                 f"Model: {model_path.name}", f"Accounting source: {grp_path.name}", "",
                 "The workbooks were opened read-only with links and macros disabled.",
                 "No accounting results or forecast ties have been verified.", "",
                 "MODEL SHEETS"]
        missing_model = []
        for name in MODEL_SHEETS:
            sheet = _sheet(model, name)
            lines.append(f"{'FOUND' if sheet else 'MISSING / DIFFERENT NAME'}  {name}")
            if not sheet:
                missing_model.append(name)
        lines += ["", "ACCOUNTING EXPORT SHEETS"]
        counts = {}
        for name in GRP_SHEETS:
            sheet = _sheet(grp, name)
            if sheet:
                counts[name] = _source_count(sheet)
                lines.append(f"FOUND  {name}: {counts[name]:,} populated rows in A:AK below row 1")
            else:
                lines.append(f"MISSING / DIFFERENT NAME  {name}")
        if len(counts) == 2:
            lines.append("CHECK  Counts agree between listing tabs: " +
                         ("YES" if len(set(counts.values())) == 1 else "NO — stop and compare listings"))
        lines += ["", "MODEL STRUCTURE"]
        accounting = _sheet(model, "Accounting FA Data")
        if accounting:
            end = min(500, accounting.UsedRange.Row + accounting.UsedRange.Rows.Count - 1)
            scan = _matrix(accounting.Range(accounting.Cells(1, 1), accounting.Cells(max(end, 1), 11)).Value2)
            candidates = projects_candidates(scan)
            if candidates:
                locations = ", ".join(f"row {row}, column {col}" for row, col in candidates[:10])
                lines.append(f"POSSIBLE 'Projects' labels: {locations}")
                lines.append("REVIEW  Confirm the green Projects boundary by viewing the model; no row was inferred automatically.")
            else:
                lines.append("REVIEW  No exact 'Projects' label in the first 500 rows of A:K.")
            lines.append(f"CURRENT  Accounting FA Data!B1 = {accounting.Range('B1').Text}")
            lines.append("REVIEW  Validate formula coverage in AL:EA, green project links, and Mobility actuals.")
        summary = _sheet(model, "Asset Level Summary")
        if summary:
            lines.append(f"CURRENT  Asset Level Summary used range: {summary.UsedRange.Address}")
        try:
            link_sources = model.LinkSources(1)
            count = len(link_sources) if link_sources else 0
            lines.append(f"CURRENT  Excel external workbook links: {count}; link targets were not opened or refreshed.")
        except Exception:
            lines.append("REVIEW  Excel external workbook links could not be enumerated.")
        lines += ["", "STEPS REQUIRING THE ACTUAL MODEL AND SOURCE REPORTS",
                  "REVIEW  Confirm exact first asset row, last asset row, project boundary and prior formula row.",
                  "REVIEW  Check that summary formulas cover every imported asset and refresh the existing pivots.",
                  "REVIEW  Tie CIP balances to CIP Accrual Listing and FA actuals to the Variance File.",
                  "REVIEW  Match Section 3 projects to CIP balance reference; remove capitalized projects.",
                  "REVIEW  Confirm project timing and column V changes with the responsible managers.",
                  "REVIEW  Confirm the monthly run-rate and Jan-2026 assumptions are still applicable.",
                  "", "STATUS: " + ("MISSING REQUIRED MODEL SHEETS" if missing_model else
                                   "STRUCTURAL CHECK COMPLETE — FULL MODEL UPDATE NOT YET CONFIGURED")]
        report_dir = Path(report_dir)
        report_dir.mkdir(parents=True, exist_ok=True)
        target = report_dir / f"Depreciation_Preflight_{dt.datetime.now():%Y%m%d_%H%M%S_%f}.txt"
        target.write_text("\n".join(lines) + "\n", encoding="utf-8")
        notify("Preflight report ready.")
        return str(target)
    finally:
        for workbook in reversed(opened):
            workbook.Close(SaveChanges=False)
        excel.Quit()
