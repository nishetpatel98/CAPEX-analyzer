@echo off
setlocal
cd /d "%~dp0"
set "SETUP_LOG=%~dp0setup.log"
>"%SETUP_LOG%" echo CAPEX Depreciation Analyzer setup

where py >nul 2>&1
if not errorlevel 1 (
  set "PY_CMD=py -3"
) else (
  where python >nul 2>&1
  if errorlevel 1 goto missing_python
  set "PY_CMD=python"
)

echo Checking Python...
%PY_CMD% -c "import sys; assert sys.version_info >= (3,10); print(sys.version)" >>"%SETUP_LOG%" 2>&1
if errorlevel 1 goto failed

echo Creating a project-local Python environment...
%PY_CMD% -m venv ".venv" >>"%SETUP_LOG%" 2>&1
if errorlevel 1 goto failed

echo Installing the Excel dependency...
".venv\Scripts\python.exe" -m pip install -r requirements.txt >>"%SETUP_LOG%" 2>&1
if errorlevel 1 goto failed

echo Setup complete. Double-click Run Analyzer.bat.
echo Setup complete.>>"%SETUP_LOG%"
pause
exit /b 0

:missing_python
echo Python is not installed or not available in PATH.>>"%SETUP_LOG%"
echo Python is missing. If this is the computer without admin access, build the portable app on your first Windows computer instead.
goto failed

:failed
echo.
echo Setup did not complete. Details are in:
echo %SETUP_LOG%
echo.
type "%SETUP_LOG%"
echo.
pause
exit /b 1
