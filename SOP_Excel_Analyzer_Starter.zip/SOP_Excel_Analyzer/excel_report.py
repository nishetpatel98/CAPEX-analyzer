"""Windows-only Excel automation. Import in the worker thread after CoInitialize."""

import datetime as dt
import os
from pathlib import Path

from analysis import AnalysisError, process, read_csv

XL_DATABASE = 1
XL_ROW = 1
XL_COLUMN = 2
XL_COUNT = -4112
XL_SUM = -4157
XL_AVERAGE = -4106
XL_CHART_TYPES = {"column": 51, "bar": 57, "line": 4}


def _matrix(value):
    if value is None:
        return []
    if not isinstance(value, tuple):
        return [[value]]
    if value and not isinstance(value[0], tuple):
        return [list(value)]
    return [list(row) for row in value]


def _write_rows(sheet, headers, rows):
    sheet.Range(sheet.Cells(1, 1), sheet.Cells(1, len(headers))).Value = tuple(headers)
    sheet.Range(sheet.Cells(1, 1), sheet.Cells(1, len(headers))).Font.Bold = True
    sheet.Range(sheet.Cells(1, 1), sheet.Cells(1, len(headers))).Interior.Color = 0xE8D7C5
    for start in range(0, len(rows), 1000):
        block = rows[start:start + 1000]
        sheet.Range(sheet.Cells(start + 2, 1), sheet.Cells(start + len(block) + 1, len(headers))).Value = tuple(tuple(row) for row in block)
    sheet.Columns.AutoFit()


def _pivot_source_address(source_range):
    # Excel exposes Address as a string property in late-bound pywin32.
    # Calling it as Address(...) raises TypeError: 'str' object is not callable.
    return "'Processed_Data'!" + source_range.Address


def _source_data(path, rules, excel):
    if path.suffix.lower() == ".csv":
        return read_csv(path)
    source = excel.Workbooks.Open(str(path), UpdateLinks=0, ReadOnly=True, IgnoreReadOnlyRecommended=True)
    try:
        name = rules.get("source_sheet")
        sheet = source.Worksheets(name) if name else source.Worksheets(1)
        used = sheet.UsedRange
        if used.Row != 1 or used.Column != 1:
            raise AnalysisError("The input table must start at cell A1.")
        if used.Rows.Count > 200001 or used.Columns.Count > 200:
            raise AnalysisError("This version supports at most 200,000 data rows and 200 columns.")
        data = _matrix(used.Value2)
        if not data:
            raise AnalysisError("The selected worksheet is empty.")
        return data[0], data[1:]
    finally:
        source.Close(SaveChanges=False)


def _create_pivot(workbook, cache, specification):
    sheet = workbook.Worksheets.Add(After=workbook.Worksheets(workbook.Worksheets.Count))
    sheet.Name = specification["name"]
    pivot = cache.CreatePivotTable(TableDestination=sheet.Range("A3"), TableName="P_" + specification["name"])
    sheet.Range("A1").Value = specification["name"].replace("_", " ")
    sheet.Range("A1").Font.Bold = True
    for position, field in enumerate(specification["rows"], 1):
        pivot.PivotFields(field).Orientation = XL_ROW
        pivot.PivotFields(field).Position = position
    for position, field in enumerate(specification.get("columns", []), 1):
        pivot.PivotFields(field).Orientation = XL_COLUMN
        pivot.PivotFields(field).Position = position
    for item in specification["values"]:
        aggregate = {"count": XL_COUNT, "sum": XL_SUM, "average": XL_AVERAGE}[item["aggregation"]]
        data_field = pivot.AddDataField(pivot.PivotFields(item["field"]), item["label"], aggregate)
        if aggregate == XL_AVERAGE:
            data_field.NumberFormat = "0.00"
    pivot.RefreshTable()
    sheet.Columns.AutoFit()
    return pivot


def build_report(input_path, output_dir, rules, *, example=False, notify=lambda message: None):
    """Build a report atomically. Requires a Windows worker thread with COM initialized."""
    path = Path(input_path).resolve()
    if not path.is_file() or path.suffix.lower() not in (".csv", ".xlsx", ".xlsm", ".xls"):
        raise AnalysisError("Choose an existing CSV or Excel file.")
    if rules["status"] != ("example" if example else "approved"):
        raise AnalysisError("These rules have not been approved for live data.")
    from win32com.client import DispatchEx

    excel = DispatchEx("Excel.Application")
    excel.Visible = False
    excel.DisplayAlerts = False
    output = None
    workbook = None
    try:
        try:
            excel.AutomationSecurity = 3  # Disable macros when opening an input workbook.
        except Exception as error:
            raise AnalysisError("Excel could not disable input workbook macros.") from error
        notify("Reading and validating input…")
        headers, rows = _source_data(path, rules, excel)
        result = process(headers, rows, rules)
        notify(f"Processing {result['source_count']:,} rows…")
        workbook = excel.Workbooks.Add()
        for index in range(workbook.Worksheets.Count, 1, -1):
            workbook.Worksheets(index).Delete()
        raw_sheet = workbook.Worksheets(1)
        raw_sheet.Name = "Raw_Data"
        _write_rows(raw_sheet, result["headers"], result["raw"])
        clean_sheet = workbook.Worksheets.Add(After=raw_sheet)
        clean_sheet.Name = "Processed_Data"
        _write_rows(clean_sheet, result["clean_headers"], result["clean"])
        for derived in rules.get("derived", []):
            if derived["operation"] == "month":
                column = result["headers"].index(derived["source"]) + 1
                raw_sheet.Columns(column).NumberFormat = "mm/dd/yyyy"
                clean_sheet.Columns(column).NumberFormat = "mm/dd/yyyy"
        last_row = len(result["clean"]) + 1
        last_column = len(result["clean_headers"])
        source_range = clean_sheet.Range(clean_sheet.Cells(1, 1), clean_sheet.Cells(last_row, last_column))
        clean_sheet.ListObjects.Add(1, source_range, None, 1).Name = "ProcessedData"
        # Excel's fully qualified R1C1 source string is stable across worksheets.
        source_address = _pivot_source_address(source_range)
        cache = workbook.PivotCaches().Create(SourceType=XL_DATABASE, SourceData=source_address)
        notify("Creating Excel PivotTables and charts…")
        pivots = {spec["name"]: _create_pivot(workbook, cache, spec) for spec in rules["pivots"]}
        if rules.get("charts"):
            charts_sheet = workbook.Worksheets.Add(After=workbook.Worksheets(workbook.Worksheets.Count))
            charts_sheet.Name = "Charts"
            charts_sheet.Range("A1").Value = "Charts based on PivotTable results"
            charts_sheet.Range("A1").Font.Bold = True
            for index, item in enumerate(rules["charts"]):
                obj = charts_sheet.ChartObjects().Add(20 + (index % 2) * 540, 45 + (index // 2) * 345, 510, 310)
                chart = obj.Chart
                chart.ChartType = XL_CHART_TYPES[item["type"]]
                chart.SetSourceData(pivots[item["pivot"]].TableRange1)
                chart.HasTitle = True
                chart.ChartTitle.Text = item["title"]
        qc = workbook.Worksheets.Add(After=workbook.Worksheets(workbook.Worksheets.Count))
        qc.Name = "QC"
        excluded = sum(issue[2] == "excluded" for issue in result["issues"])
        invalid = sum(issue[2] == "invalid" for issue in result["issues"])
        details = [("Rule version", rules["version"]), ("Input filename", path.name),
                   ("Source data rows", result["source_count"]), ("Retained rows", len(result["clean"])),
                   ("Excluded rows", excluded), ("Invalid rows", invalid),
                   ("QC status", "REVIEW REQUIRED" if invalid else "Completed; review exclusions")]
        _write_rows(qc, ["Check", "Value"], details)
        if result["issues"]:
            qc.Range("A11:C11").Value = ("Source row", "Reason", "Type")
            qc.Range("A11:C11").Font.Bold = True
            qc.Range(qc.Cells(12, 1), qc.Cells(11 + len(result["issues"]), 3)).Value = tuple(result["issues"])
            qc.Columns.AutoFit()
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        name = f"{path.stem}_Analysis_{dt.datetime.now():%Y%m%d_%H%M%S_%f}.xlsx"
        output = output_dir / name
        workbook.SaveAs(str(output), FileFormat=51)
        workbook.Close(SaveChanges=False)
        workbook = None
        notify("Report complete.")
        return str(output), result
    except Exception:
        if output is not None:
            try:
                os.remove(output)
            except OSError:
                pass
        raise
    finally:
        if workbook is not None:
            workbook.Close(SaveChanges=False)
        excel.Quit()
