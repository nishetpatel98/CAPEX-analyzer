"""Small, deterministic subset of SOP rules; no network or model calls."""

import csv
import datetime as dt
import json
import math
import re
from pathlib import Path


class AnalysisError(ValueError):
    pass


def load_rules(path):
    with open(path, encoding="utf-8") as handle:
        rules = json.load(handle)
    if rules.get("status") not in ("example", "approved"):
        raise AnalysisError("Rules must have status 'example' or 'approved'.")
    if not rules.get("version") or not rules.get("required_columns") or not rules.get("pivots"):
        raise AnalysisError("Rules need a version, required columns and pivots.")
    names = [p["name"] for p in rules["pivots"]]
    if len(set(names)) != len(names) or any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]{0,29}", n) for n in names):
        raise AnalysisError("Pivot names must be unique Excel-safe identifiers (30 characters maximum).")
    for pivot in rules["pivots"]:
        if not pivot.get("rows") or not pivot.get("values"):
            raise AnalysisError(f"Pivot {pivot['name']} needs rows and values.")
        if pivot["name"] in ("Raw_Data", "Processed_Data", "Charts", "QC"):
            raise AnalysisError(f"Reserved sheet name: {pivot['name']}")
        for value in pivot["values"]:
            if value.get("aggregation") not in ("count", "sum", "average"):
                raise AnalysisError(f"Unsupported aggregation in {pivot['name']}")
            if not value.get("label") or value["label"] == value.get("field"):
                raise AnalysisError("A value needs a distinct label different from the source field.")
    for chart in rules.get("charts", []):
        if chart.get("pivot") not in names or chart.get("type") not in ("column", "bar", "line"):
            raise AnalysisError("Chart needs an existing pivot and column, bar or line type.")
    return rules


def read_csv(path):
    with open(path, encoding="utf-8-sig", newline="") as handle:
        sample = handle.read(4096)
        handle.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
        except csv.Error:
            dialect = csv.excel
        reader = csv.reader(handle, dialect)
        return next(reader, []), list(reader)


def _date_month(value):
    if isinstance(value, (float, int)) and not isinstance(value, bool):
        date = (dt.datetime(1899, 12, 30) + dt.timedelta(days=value)).date()
    elif isinstance(value, dt.datetime):
        date = value.date()
    elif isinstance(value, dt.date):
        date = value
    else:
        text = str(value).strip()
        date = None
        for fmt in ("%Y-%m-%d", "%Y-%m-%d %H:%M:%S", "%m/%d/%Y", "%m/%d/%y"):
            try:
                date = dt.datetime.strptime(text, fmt).date()
                break
            except ValueError:
                pass
        if date is None:
            raise AnalysisError(f"Unrecognized date: {text[:50]}")
    return date.strftime("%Y-%m")


def validate_headers(headers, rules):
    headers = [str(v).strip() if v is not None else "" for v in headers]
    if not headers or not all(headers):
        raise AnalysisError("Input needs nonblank column names in the first row.")
    if len(set(h.casefold() for h in headers)) != len(headers):
        raise AnalysisError("Input column names must be unique, ignoring case.")
    missing = [h for h in rules["required_columns"] if h not in headers]
    if missing:
        raise AnalysisError("Missing required columns: " + ", ".join(missing))
    available = set(headers)
    for rule in rules.get("filters", []):
        if rule.get("field") not in available:
            raise AnalysisError(f"Rules refer to missing column: {rule.get('field')}")
        if ("include" in rule) == ("exclude" in rule):
            raise AnalysisError("Each filter needs exactly one include or exclude list.")
    for rule in rules.get("derived", []):
        if rule.get("source") not in available:
            raise AnalysisError(f"Rules refer to missing column: {rule.get('source')}")
        if rule.get("operation") not in ("month", "equals"):
            raise AnalysisError(f"Unsupported derived operation: {rule.get('operation')}")
        new_field = rule.get("field")
        if not new_field or new_field in available:
            raise AnalysisError(f"Derived field must be new and named: {new_field}")
        available.add(new_field)
    for pivot in rules["pivots"]:
        for field in pivot["rows"] + pivot.get("columns", []) + [v["field"] for v in pivot["values"]]:
            if field not in available:
                raise AnalysisError(f"Pivot {pivot['name']} refers to missing column: {field}")
    return headers


def process(headers, rows, rules):
    headers = validate_headers(headers, rules)
    derived_names = [rule["field"] for rule in rules.get("derived", [])]
    raw = []
    clean = []
    issues = []
    for row_number, input_row in enumerate(rows, start=2):
        input_row = list(input_row)
        if len(input_row) > len(headers):
            issues.append((row_number, "Extra cells beyond the header", "invalid"))
            continue
        padded = input_row + [None] * (len(headers) - len(input_row))
        raw.append(padded)
        record = dict(zip(headers, padded))
        if all(v is None or str(v).strip() == "" for v in padded):
            issues.append((row_number, "Blank row", "excluded"))
            continue
        if any(record[f] is None or str(record[f]).strip() == "" for f in rules["required_columns"]):
            issues.append((row_number, "Missing required value", "invalid"))
            continue
        excluded = False
        for rule in rules.get("filters", []):
            item = str(record[rule["field"]]).strip().casefold()
            if "exclude" in rule and item in {str(v).casefold() for v in rule["exclude"]}:
                excluded = True
            elif "include" in rule and item not in {str(v).casefold() for v in rule["include"]}:
                excluded = True
            if excluded:
                issues.append((row_number, f"Filtered: {rule['field']}", "excluded"))
                break
        if excluded:
            continue
        try:
            for rule in rules.get("derived", []):
                if rule["operation"] == "month":
                    record[rule["field"]] = _date_month(record[rule["source"]])
                else:
                    record[rule["field"]] = int(str(record[rule["source"]]).strip().casefold() == str(rule["value"]).casefold())
            for pivot in rules["pivots"]:
                for val in pivot["values"]:
                    if val["aggregation"] in ("sum", "average"):
                        record[val["field"]] = float(record[val["field"]])
                        if not math.isfinite(record[val["field"]]):
                            raise AnalysisError("Non-finite numeric value")
        except (AnalysisError, ValueError, TypeError, OverflowError) as error:
            issues.append((row_number, f"Invalid calculation: {error}", "invalid"))
            continue
        clean.append([record[h] for h in headers + derived_names])
    if not clean:
        raise AnalysisError("No valid records remain after applying the rules.")
    return {"headers": headers, "raw": raw, "clean_headers": headers + derived_names,
            "clean": clean, "issues": issues, "source_count": len(rows)}
